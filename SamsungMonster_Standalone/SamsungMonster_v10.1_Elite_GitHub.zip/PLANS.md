# Plano de Restauração Cirúrgica - Samsung Monster GUI

Este documento descreve o inventário atual, as lacunas detectadas e o roteiro para a restauração da interface e integrações do projeto.

## 1. Inventário da GUI Atual

### Visíveis e Funcionais (Parcialmente)
- **Dashboard**: Leitura básica de info, reboots (System, Download).
- **Firmware**: Odin Flash (5 slots), Smart Repair (Cloud), Hybrid Engine.
- **Security**: FRP Bypass (Download/MTP), MDM Bypass, Exploit Lab (Ghost PIT, SysUI Crash).
- **Service**: RF Lab (IMEI, CSC), Chipsets (EDL, BROM, EUB), Tools (Auto-Repair).
- **Resources**: QR Gen (MDM), Driver Doctor (Básico), Full Logs.

### Ocultos/Incompletos/Quebrados
- **Partitions**: Tabela de partições vazia, sem lógica de listagem ou interação.
- **RF Lab**: Faltam funções de Backup EFS, Repair Network e Patch Certificate (implementadas no backend mas não ligadas).
- **Repair SN**: Botão sem efeito (handler órfão).
- **Schematics**: Conteúdo estático de exemplo.
- **Mode Awareness**: Botões ativos mesmo quando o protocolo não suporta a operação (ex: Flash em modo Modem).

## 2. Lacunas Detectadas (Backend vs GUI)

| Recurso | Status Backend | Status GUI | Ação Necessária |
| :--- | :--- | :--- | :--- |
| **Listar Partições** | Implementado nos protocolos | Handler vazio | Ligar Orchestrator à UI Table |
| **Backup EFS** | Implementado em `SamsungOperations` | Inexistente | Adicionar botão em RF Lab/Tools |
| **Repair Network** | Implementado em `SamsungOperations` | Inexistente | Adicionar botão em RF Lab |
| **Patch Certificate**| Implementado em `SamsungOperations` | Inexistente | Adicionar botão em RF Lab |
| **Repair Serial** | Não implementado | Botão órfão | Implementar em Ops e Orchestrator |
| **Auto-Detect Loaders**| Implementado em `LoaderManager` | Parcial | Validar detecção automática em Chipsets |

## 3. Ordem de Restauração por Prioridade

### Etapa 1: Alinhamento de Infraestrutura (Orchestrator) - [CONCLUÍDO]
- [x] Adicionar `list_partitions` ao `TaskOrchestrator`.
- [x] Adicionar `backup_efs`, `repair_network` e `patch_certificate` ao `TaskOrchestrator`.
- [x] Implementar `repair_serial` na camada de `SamsungOperations` e `Orchestrator`.

### Etapa 2: Restauração do Partition Manager - [CONCLUÍDO]
- [x] Implementar `_refresh_partitions` em `gui.py`.
- [x] Popular `QTableWidget` com Nome, Tamanho e Ações (Read, Erase).
- [x] Ligar ações de partição ao backend.

### Etapa 3: Expansão do RF Lab & Security - [CONCLUÍDO]
- [x] Integrar botões de Backup EFS, Repair Network e Patch Certificate no `RF LAB`.
- [x] Garantir que o `RF LAB` use o protocolo correto (Modem ou EUB/EDL).
- [x] Implementar e ligar `repair_serial` (S/N).

### Etapa 4: Estabilidade e UX - [CONCLUÍDO]
- [x] Implementar trava de segurança (disable buttons) baseada no modo atual do dispositivo.
- [x] Melhorar o `Driver Doctor` para diagnosticar drivers Samsung ausentes.
- [x] Adicionar feedback visual de progresso e logs detalhados para novas funções.

### Etapa 5: Suporte a Chipsets e Cloud - [CONCLUÍDO]
- [x] Integrar handlers de EDL Flash, EUB Loader e BROM Boot no Orchestrator.
- [x] Ligar botões na aba de Chipsets e garantir mode-awareness.
- [x] Expandir base de dados de SoCs (Qualcomm, MediaTek, Exynos) em `DeviceDatabase`.
- [x] Integrar `Soft-Brick Fix` via download automático e mapeamento de firmware.

### Etapa 6: Integração de Scripts Standalone - [CONCLUÍDO]
- [x] Integrar `deep_diagnose.py`, `brute_handshake.py`, `force_reboot.py` e `identify_apparel.py`.
- [x] Corrigir estabilidade USB e restaurar leitura automática.

### Etapa 7: Integração de Protocolos Ocultos e Payloads - [CONCLUÍDO]
- [x] Ativar e expor protocolo Unisoc SPD.
- [x] Implementar injeção de Payloads binários.

## Plano Atual: Integração Profunda de Hardware e Cloud - [CONCLUÍDO]
- [x] Implementar `AT+DEVCONINFO` para leitura de BIT real (SWREV).
- [x] Adicionar `Smart Bridge Toggle` para downgrades automáticos e seguros.
- [x] Estabilizar barramento USB via `USB_GLOBAL_LOCK` (Zero "Resource busy").
- [x] Implementar parser real para SamFW no `FirmwareFetcher` (BS4).

## Próximos Passos
1. Validar injeção de payloads em partições de segurança (PARAM/STEADY).
2. Expandir continuamente a base de dados de `Test Points` no tab de Schematics.
3. Adicionar suporte a `Soft-Brick Fix` via download automático de PIT específico.

### Checkpoint: Sistema Integrado e Estável
- [x] GUI 100% acessível e sincronizada.
- [x] Leitura de hardware automática (Bit/Model) robusta em One UI 6.1+.
- [x] Fluxo de Cloud Repair integrado com scraping real.
- [x] **Preservado**: Toda a lógica de baixo nível dos protocolos originais sem regressões.

