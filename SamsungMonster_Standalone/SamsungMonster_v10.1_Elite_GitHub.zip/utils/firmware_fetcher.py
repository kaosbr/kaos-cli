"""Firmware Fetcher & Cloud Engine - Samsung Monster Standalone"""
import os
import requests
import logging
import zipfile
import shutil
import re
from typing import Optional, Dict, List
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

class FirmwareFetcher:
    """Expert tool to find and download Samsung firmwares using SamFW public base"""
    
    SAMFW_BASE = "https://samfw.com/firmware"
    TEMP_DIR = "temp_firmware"
    USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"

    @staticmethod
    def get_samfw_firmware(model: str, region: str, target_bit: Optional[str] = None, bridge_mode: bool = False) -> Optional[Dict]:
        """Scrape SamFW to find the best firmware (Latest, Downgrade or Bridge)"""
        url = f"{FirmwareFetcher.SAMFW_BASE}/{model}/{region}"
        headers = {"User-Agent": FirmwareFetcher.USER_AGENT}
        
        try:
            logger.info(f"🔍 Scraping SamFW for {model} [{region}]...")
            resp = requests.get(url, headers=headers, timeout=15)
            resp.raise_for_status()
            
            soup = BeautifulSoup(resp.text, "html.parser")
            table = soup.find("table")
            if not table:
                logger.error("❌ Firmware table not found on SamFW.")
                return None
            
            candidates = []
            rows = table.find_all("tr")[1:] # Skip header
            
            for row in rows:
                cols = row.find_all("td")
                if len(cols) < 5: continue
                
                version = cols[0].get_text(strip=True)
                os_ver = cols[1].get_text(strip=True)
                date = cols[2].get_text(strip=True)
                
                # Extract Bit from PDA (e.g. S918BXXU3AWF7 -> Bit 3)
                # PDA is usually the first part of version, the bit is 5th char from end
                pda = version.split("/")[0] if "/" in version else version
                bit = pda[-5] if len(pda) > 5 else "0"
                
                link_tag = cols[-1].find("a")
                download_url = link_tag["href"] if link_tag else ""
                
                candidates.append({
                    "version": version,
                    "os": os_ver,
                    "date": date,
                    "bit": bit,
                    "download_url": download_url if download_url.startswith("http") else f"https://samfw.com{download_url}"
                })

            if not candidates: return None

            # Filter by Target Bit if provided (Crucial for Anti-Brick)
            if target_bit:
                candidates = [c for c in candidates if c['bit'] == str(target_bit)]
            
            if not candidates:
                logger.warning(f"⚠️ No firmware found for Bit {target_bit}")
                return None

            # Smart Bridge Logic: Find the oldest patch for the same Bit (to maximize exploit success)
            if bridge_mode:
                # Sort by date ascending
                candidates.sort(key=lambda x: x['date'])
                selected = candidates[0]
                logger.info(f"🌉 Bridge Mode: Selected oldest firmware {selected['version']} (Bit {selected['bit']})")
                return selected
            
            # Latest Logic:
            candidates.sort(key=lambda x: x['date'], reverse=True)
            return candidates[0]

        except Exception as e:
            logger.error(f"Scraping error: {e}")
            return None

    @staticmethod
    def get_latest_firmware(model: str, region: str) -> Optional[Dict]:
        """Legacy compatibility - forwards to SamFW engine"""
        return FirmwareFetcher.get_samfw_firmware(model, region)

    @staticmethod
    def download_and_extract(page_url: str, progress_cb=None) -> Optional[str]:
        """Resolve direct link, download with Speed/ETA and extract"""
        headers = {"User-Agent": FirmwareFetcher.USER_AGENT}
        
        try:
            # Step 1: Resolve Direct Link from SamFW Page
            logger.info(f"🔗 Resolving direct download link from {page_url}...")
            resp = requests.get(page_url, headers=headers, timeout=10)
            # Find the download button or script variable with the real link
            # SamFW typically uses a 'server' parameter or a direct CDN link
            match = re.search(r'https://samfw\.com/download/[^"\']+', resp.text)
            direct_url = match.group(0) if match else page_url
            
            if os.path.exists(FirmwareFetcher.TEMP_DIR):
                shutil.rmtree(FirmwareFetcher.TEMP_DIR)
            os.makedirs(FirmwareFetcher.TEMP_DIR)
            
            target_path = os.path.join(FirmwareFetcher.TEMP_DIR, "fw.zip")
            
            # Step 2: Download with High-Precision Monitor
            import time
            start_time = time.time()
            with requests.get(direct_url, stream=True, headers=headers) as r:
                r.raise_for_status()
                total = int(r.headers.get('content-length', 0))
                done = 0
                
                with open(target_path, "wb") as f:
                    for chunk in r.iter_content(chunk_size=1024*1024): # 1MB chunks
                        if chunk:
                            f.write(chunk)
                            done += len(chunk)
                            
                            # Calculate Speed and ETA
                            elapsed = time.time() - start_time
                            speed = done / elapsed if elapsed > 0 else 0 # bytes/s
                            eta = (total - done) / speed if speed > 0 else 0
                            
                            if progress_cb:
                                progress_info = {
                                    "percent": int((done/total)*100) if total > 0 else 0,
                                    "speed": f"{speed/1024/1024:.2f} MB/s",
                                    "eta": f"{int(eta)}s",
                                    "stage": f"Downloading: {done/1024/1024:.1f}MB / {total/1024/1024:.1f}MB"
                                }
                                progress_cb(progress_info)
            
            logger.info("📦 Download complete. Extracting .tar.md5 files...")
            with zipfile.ZipFile(target_path, 'r') as z:
                z.extractall(FirmwareFetcher.TEMP_DIR)
            
            return FirmwareFetcher.TEMP_DIR
        except Exception as e:
            logger.error(f"❌ Download/Extract error: {e}")
            return None

    @staticmethod
    def map_extracted_files(path: str) -> Dict[str, str]:
        """Map files (BL, AP, CP, CSC) based on Samsung naming convention"""
        mapping = {}
        for f in os.listdir(path):
            if f.startswith("BL_"): mapping["BL"] = os.path.join(path, f)
            elif f.startswith("AP_"): mapping["AP"] = os.path.join(path, f)
            elif f.startswith("CP_"): mapping["CP"] = os.path.join(path, f)
            elif f.startswith("CSC_"): mapping["CSC"] = os.path.join(path, f)
        return mapping
