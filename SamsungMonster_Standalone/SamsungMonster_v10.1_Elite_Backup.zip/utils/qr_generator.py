"""Samsung MDM/KG QR Provisioning Generator - Samsung Monster Standalone"""
import json
import base64
import hashlib
import qrcode
from io import BytesIO

class MDMQRGenerator:
    """Expert tool for creating Enterprise DPC Provisioning QR Codes"""

    DEFAULT_DPC_PACKAGE = "com.monster.dpc"
    DEFAULT_DPC_RECEIVER = "com.monster.dpc.MonsterAdminReceiver"
    DEFAULT_DPC_DOWNLOAD = "https://monster-tool.com/downloads/monster_dpc.apk"
    DEFAULT_DPC_CHECKSUM = "V7_u6Y_7hY8p_Y8pY8pY8pY8pY8pY8pY8pY8pY8pY8p"

    @staticmethod
    def generate_provisioning_json(
        package_name: str = DEFAULT_DPC_PACKAGE,
        download_url: str = DEFAULT_DPC_DOWNLOAD,
        checksum: str = DEFAULT_DPC_CHECKSUM,
        extras: dict = None
    ) -> str:
        """Generate the standard Android Enterprise Provisioning JSON with One UI 8 Support"""
        
        provisioning_data = {
            "android.app.extra.PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME": f"{package_name}/{MDMQRGenerator.DEFAULT_DPC_RECEIVER}",
            "android.app.extra.PROVISIONING_DEVICE_ADMIN_PACKAGE_DOWNLOAD_LOCATION": download_url,
            "android.app.extra.PROVISIONING_DEVICE_ADMIN_PACKAGE_CHECKSUM": checksum,
            "android.app.extra.PROVISIONING_LEAVE_ALL_SYSTEM_APPS_ENABLED": True,
            "android.app.extra.PROVISIONING_SKIP_ENCRYPTION": True,
            "android.app.extra.PROVISIONING_ALLOW_OFFLINE": True, # One UI 8 Offline Bypass
            "android.app.extra.PROVISIONING_KEEP_SCREEN_ON": True,
            "android.app.extra.PROVISIONING_ADMIN_EXTRAS_BUNDLE": extras or {}
        }
        
        return json.dumps(provisioning_data, separators=(',', ':'))

    @staticmethod
    def generate_qr_pixmap_data() -> bytes:
        """Generate QR Code image data in PNG format"""
        json_data = MDMQRGenerator.generate_monster_bypass_string()
        qr = qrcode.QRCode(version=1, box_size=10, border=4)
        qr.add_data(json_data)
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        buffer = BytesIO()
        img.save(buffer, format="PNG")
        return buffer.getvalue()

    @staticmethod
    def save_qr_image(path: str) -> bool:
        """Generate and save QR Code image to file"""
        try:
            json_data = MDMQRGenerator.generate_monster_bypass_string()
            qr = qrcode.QRCode(version=1, box_size=10, border=4)
            qr.add_data(json_data)
            qr.make(fit=True)
            img = qr.make_image(fill_color="black", back_color="white")
            img.save(path, format="PNG")
            return True
        except: return False

    @staticmethod
    def generate_monster_bypass_string() -> str:
        """Pre-configured bypass string for Samsung MDM/KG Removal (One UI 8 Ready)"""
        return MDMQRGenerator.generate_provisioning_json(
            extras={
                "monster_bypass": True,
                "disable_knox": True,
                "disable_mdm": True,
                "enable_adb": True,
                "hide_dpc": True, # Makes the DPC app invisible
                "skip_wifi": True  # Attempt to skip wifi setup if possible
            }
        )
