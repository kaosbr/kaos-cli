"""Simplified Device Database for Samsung Monster"""
import logging

logger = logging.getLogger(__name__)

class DeviceDatabase:
    """Minimal database for Samsung chipsets"""
    
    CHIPSETS = {
        # Exynos
        0x3830: {"chipset": "Exynos 850 (S5E3830)", "type": "Exynos"},
        0x7870: {"chipset": "Exynos 7870", "type": "Exynos"},
        0x7884: {"chipset": "Exynos 7884", "type": "Exynos"},
        0x7885: {"chipset": "Exynos 7885", "type": "Exynos"},
        0x7904: {"chipset": "Exynos 7904", "type": "Exynos"},
        0x8895: {"chipset": "Exynos 8895", "type": "Exynos"},
        0x9110: {"chipset": "Exynos 9110", "type": "Exynos"},
        0x9610: {"chipset": "Exynos 9610", "type": "Exynos"},
        0x9611: {"chipset": "Exynos 9611", "type": "Exynos"},
        0x9810: {"chipset": "Exynos 9810", "type": "Exynos"},
        0x9820: {"chipset": "Exynos 9820", "type": "Exynos"},
        0x9825: {"chipset": "Exynos 9825", "type": "Exynos"},
        0x990:  {"chipset": "Exynos 990", "type": "Exynos"},
        0x2100: {"chipset": "Exynos 2100", "type": "Exynos"},
        0x2200: {"chipset": "Exynos 2200", "type": "Exynos"},
        
        # Qualcomm (MSM/SDM)
        0x0008E0E1: {"chipset": "Snapdragon 8 Gen 1", "type": "Qualcomm"},
        0x0013E0E1: {"chipset": "Snapdragon 888", "type": "Qualcomm"},
        0x000940E1: {"chipset": "Snapdragon 865", "type": "Qualcomm"},
        0x000700E1: {"chipset": "Snapdragon 855", "type": "Qualcomm"},
        0x000520E1: {"chipset": "Snapdragon 845", "type": "Qualcomm"},
        
        # MediaTek (MT)
        0x0767: {"chipset": "Dimensity 9000", "type": "MediaTek"},
        0x0817: {"chipset": "Dimensity 1200", "type": "MediaTek"},
        0x6765: {"chipset": "Helio G35", "type": "MediaTek"},
        0x6768: {"chipset": "Helio G80/G85", "type": "MediaTek"},
    }

    def identify_by_hwid(self, hwid: int) -> dict:
        """Lookup chipset info by HWID"""
        return self.CHIPSETS.get(hwid, {"chipset": f"Unknown SoC (0x{hwid:08X})", "type": "Unknown"})
