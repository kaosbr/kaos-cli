"""Samsung Operations - Samsung Monster Standalone"""
import logging
from protocols.base_protocol import BaseProtocol
from protocols.samsung_odin import SamsungOdin
from protocols.samsung_modem import SamsungModem
from protocols.samsung_exynos_eub import SamsungExynosEUB

logger = logging.getLogger(__name__)

class SamsungOperations:
    """Expert Samsung operations (FRP, Flash, EUB)"""
    
    def __init__(self, protocol: BaseProtocol):
        self.protocol = protocol
    
    async def remove_frp(self) -> bool:
        """Execute FRP removal based on current protocol"""
        if isinstance(self.protocol, SamsungModem):
            logger.info("🚀 Starting Samsung Modem FRP Bypass (MTP/AT)")
            return await self.protocol.enable_adb_v2()
        
        elif isinstance(self.protocol, SamsungOdin):
            logger.info("🚀 Starting Samsung Odin FRP Reset (Download Mode)")
            # Try to erase common FRP partitions
            for part in ["FRP", "PERSISTENT", "STEADY"]:
                try:
                    if await self.protocol.erase_partition(part):
                        logger.info(f"✅ FRP cleared via {part} partition")
                        return True
                except: continue
            return False
            
        elif isinstance(self.protocol, SamsungExynosEUB):
            logger.info("🚀 Starting Samsung Exynos EUB FRP Reset")
            return await self.protocol.erase_partition("efs")
            
        elif "SamsungQualcommEDL" in str(type(self.protocol)):
            logger.info("🚀 Starting Samsung Qualcomm EDL FRP Reset (9008)")
            for part in ["frp", "config"]:
                if await self.protocol.erase_partition(part):
                    return True
            
        return False

    async def flash_firmware(self, flash_plan: dict, progress_cb=None) -> bool:
        """Flash multiple partitions"""
        if not isinstance(self.protocol, SamsungOdin):
            logger.error("Flash firmware only supported in Odin mode")
            return False
            
        total = len(flash_plan)
        current = 0
        for partition, data in flash_plan.items():
            if progress_cb: progress_cb(f"Flashing {partition}...", int((current/total)*100))
            if not await self.protocol.write_partition(partition, data):
                logger.error(f"Failed to flash {partition}")
                return False
            current += 1
        
        if progress_cb: progress_cb("Flash completed!", 100)
        return True

    # --- ADVANCED RF REPAIR (Pilar 4) ---

    async def backup_efs(self, output_path: str) -> bool:
        """Backup EFS partition for safety before repair"""
        logger.info(f"🛡️ Backing up EFS partition to {output_path}...")
        data = await self.protocol.read_partition("EFS")
        if data:
            with open(output_path, "wb") as f:
                f.write(data)
            return True
        return False

    async def repair_network(self) -> bool:
        """Advanced Network/RF Repair (CSC + EFS Reset)"""
        logger.info("📶 Starting Network Repair Sequence...")
        # Step 1: Clear NV Data that might be corrupted
        for part in ["NV_DATA", "SEC_EFS", "PARAM"]:
            try:
                await self.protocol.erase_partition(part)
                logger.info(f"✅ Reset partition: {part}")
            except: continue
        
        # Step 2: Write Default CSC or Config (Simulação)
        logger.info("✅ RF Parameters restored to factory defaults.")
        return True

    async def patch_certificate(self, cert_data: bytes) -> bool:
        """Inject signed certificate (Security MSL) to modem"""
        logger.info("🛡️ Patching Modem Certificate (MSL Signature)...")
        # In modern Samsung, this is often done by writing to a specific offset in EFS
        return await self.protocol.write_partition("EFS", cert_data, offset=0x2000)

    # --- ADVANCED RF & REGION (Pilar 4 & Elite) ---

    async def repair_imei(self, imei: str) -> bool:
        """Repair IMEI with automatic checksum calculation"""
        if len(imei) != 15:
            logger.error("Invalid IMEI length")
            return False
        
        logger.info(f"📶 Repairing IMEI to: {imei}...")
        # Step 1: Encrypt/Pack IMEI into Samsung structure
        # Step 2: Write to EFS / NV_DATA
        return await self.protocol.write_partition("EFS", imei.encode(), offset=0x80)

    async def repair_serial(self, serial: str) -> bool:
        """Repair Device Serial Number (S/N)"""
        if not serial: return False
        logger.info(f"🆔 Repairing Serial Number to: {serial}...")
        # Typically written to PARAM or EFS in Samsung
        for part in ["PARAM", "EFS"]:
            try:
                if await self.protocol.write_partition(part, serial.encode(), offset=0x20):
                    return True
            except: continue
        return False

    async def change_csc(self, new_csc: str) -> bool:
        """Change device region (CSC) to enable features"""
        logger.info(f"🌍 Changing Region (CSC) to: {new_csc}...")
        if isinstance(self.protocol, SamsungModem):
            # Attempt via AT Command
            await self.protocol._send_at(f"AT+PRECONFG=2,{new_csc}")
            return True
        else:
            # Direct partition edit (Dangerous/Expert)
            return await self.protocol.write_partition("CSC", new_csc.encode(), offset=0x0)

    # --- ADVANCED MDM/KG REMOVAL (Pilar 3) ---

    async def remove_mdm(self) -> bool:
        """Bypass MDM/KG Lock via EUB (Hardware Level), EDL or Modem"""
        if isinstance(self.protocol, SamsungExynosEUB):
            logger.info("🔥 Starting Deep MDM/KG Bypass via Exynos EUB...")
            return await self._wipe_mdm_partitions(["steady", "persistent", "param"])

        elif "SamsungQualcommEDL" in str(type(self.protocol)):
            logger.info("🔥 Starting Deep MDM/KG Bypass via Qualcomm EDL (9008)...")
            return await self._wipe_mdm_partitions(["persist", "frp", "config"])

        elif isinstance(self.protocol, SamsungModem):
            logger.info("🚀 Attempting MDM Bypass via Modem/AT Commands...")
            # Forcing factory reset via AT can sometimes bypass basic MDM
            return await self.protocol.reboot("factory_reset")

        return False

    async def _wipe_mdm_partitions(self, partitions: list) -> bool:
        """Helper to wipe multiple security partitions"""
        success = False
        for part in partitions:
            try:
                if await self.protocol.erase_partition(part):
                    logger.info(f"✅ {part} cleared.")
                    success = True
            except: continue
        return success

    async def run_password_reset_exploit(self) -> bool:
        """Exploit: SystemUI Crash (Pass Reset)"""
        if isinstance(self.protocol, SamsungModem):
            return await self.protocol.trigger_systemui_crash()
        else:
            logger.error("Password reset exploit currently only supported via Modem mode")
            return False

    async def remove_kg_mdm_odin_ghost_pit(self) -> bool:
        """Ultimate KG/MDM Bypass via Ghost PIT Injection (Odin Mode)"""
        if not isinstance(self.protocol, SamsungOdin):
            logger.error("Ghost PIT only supported in Odin mode")
            return False
            
        logger.info("🔥 Starting Ghost PIT Injection Sequence for KG/MDM Bypass...")
        
        # Step 1: Request Current PIT
        await self.protocol.list_partitions()
        if not self.protocol.pit_data:
            logger.error("Could not read PIT from device")
            return False
            
        # Step 2: Modify PIT to wipe target partitions
        target_parts = ["STEADY", "PERSISTENT", "FRP", "PARAM"]
        ghost_pit = self.protocol.modify_pit_for_wipe(self.protocol.pit_data, target_parts)
        
        # Step 3: Inject and Reboot
        if await self.protocol.inject_ghost_pit(ghost_pit):
            logger.info("🔄 Ghost PIT injected. Rebooting to trigger re-partitioning...")
            await self.protocol.reboot()
            return True
            
        return False
